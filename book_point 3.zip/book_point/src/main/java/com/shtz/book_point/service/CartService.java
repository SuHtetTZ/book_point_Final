package com.shtz.book_point.service;

import org.springframework.stereotype.Service;

import com.shtz.book_point.entity.Book;
import com.shtz.book_point.entity.CartItem;

import jakarta.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {
	
	private static final String CART_SESSION_KEY = "cart";

    @SuppressWarnings("unchecked")
    private List<CartItem> getCart(HttpSession session) {
        List<CartItem> cart = (List<CartItem>) session.getAttribute(CART_SESSION_KEY);
        if (cart == null) {
            cart = new ArrayList<>();
            session.setAttribute(CART_SESSION_KEY, cart);
        }
        return cart;
    }

    public void addToCart(HttpSession session, Book book, int quantity) {
        List<CartItem> cart = getCart(session);

        // Check if the book is already in the cart
        Optional<CartItem> existingItem = cart.stream()
            .filter(item -> item.getBook().getId() == book.getId()) // Use '==' instead of equals()
            .findFirst();

        if (existingItem.isPresent()) {
            existingItem.get().setQuantity(existingItem.get().getQuantity() + quantity);
        } else {
            cart.add(new CartItem(book, quantity));
        }

        session.setAttribute("cart", cart);
    }


    public void removeFromCart(HttpSession session, int bookId) {
        List<CartItem> cart = getCart(session);
        cart.removeIf(item -> item.getBook().getId() == bookId); // Use '==' instead of .equals()
        session.setAttribute(CART_SESSION_KEY, cart);
    }

    public void clearCart(HttpSession session) {
        session.removeAttribute(CART_SESSION_KEY);
    }
    
    public int calculateTotalPrice(HttpSession session) {
        return getCart(session).stream()
            .mapToInt(CartItem::getTotalPrice) // Uses getTotalPrice() in CartItem
            .sum();
    }

}
