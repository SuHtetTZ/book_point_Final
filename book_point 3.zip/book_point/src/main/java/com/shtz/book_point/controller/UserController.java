package com.shtz.book_point.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shtz.book_point.entity.User;
import com.shtz.book_point.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	// Welcome page
	@GetMapping("/")
	public String welcome(Model model) {
		model.addAttribute("message", "Welcome! Do you have an account?");
		return "welcome";
	}

	// Register page
	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		return "register";
	}

	// Handle registration with validation
	@PostMapping("/register")
	public String registerUser(@ModelAttribute User user, Model model) {
		try {
            userService.registerUser(user);
            return "redirect:/login"; // Redirect to login page on successful registration
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "register"; // Return to registration page with error message
        }
	}

	// Login page
	@GetMapping("/login")
	public String showLoginForm() {
		return "login";
	}

	// Handle login
	@PostMapping("/login")
	public String loginUser(@RequestParam String email, @RequestParam String password, HttpSession session, Model model) {
	    try {
	        User user = userService.loginUser(email, password);
	        
	        // Store the username in session
	        session.setAttribute("username", user.getUsername());
	        session.setAttribute("user", user);

	        return "redirect:/dashboard"; // Successful login, redirect to dashboard
	    } catch (IllegalArgumentException e) {
	        model.addAttribute("error", e.getMessage());
	        return "login"; // Show login page again with the error message
	    }
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
	    session.invalidate(); // Invalidate the session, clearing all attributes
	    return "redirect:/login"; // Redirect to login page after logging out
	}
	
	@GetMapping("/profile")
	public String showProfile(HttpSession session, Model model) {
	    // Get the user object from session
	    User user = (User) session.getAttribute("user");
	    String username = (String) session.getAttribute("username");
	    
	    // If no user is found in session, redirect to login page
	    if (user == null) {
	        return "redirect:/login";
	    }

	    // Add the user data to the model
	    model.addAttribute("user", user);
	    model.addAttribute("username", username);
	    return "profile"; // Return to profile.html view
	}
	@GetMapping("/editProfile")
	public String showEditProfileForm(HttpSession session, Model model) {
	    User user = (User) session.getAttribute("user");
	    String username = (String) session.getAttribute("username");

	    if (user == null) {
	        return "redirect:/login";
	    }

	    model.addAttribute("user", user);
	    model.addAttribute("username", username);
	    return "editProfile"; // New page for editing profile info
	}
	@PostMapping("/updateProfile")
	public String updateProfile(@ModelAttribute User user, HttpSession session, Model model) {
	    User loggedInUser = (User) session.getAttribute("user");
	    String username = (String) session.getAttribute("username");

	    if (loggedInUser == null) {
	        return "redirect:/login";
	    }

	    // Check if password is null or empty and retain the old password if so
	    if (user.getPassword() == null || user.getPassword().isEmpty()) {
	        user.setPassword(loggedInUser.getPassword()); // Keep the old password
	    }

	    // Set the ID of the logged-in user to ensure it remains unchanged
	    user.setId(loggedInUser.getId());

	    // Call service to update the user data
	    userService.updateUserProfile(user);

	    // Update the session with the new user data
	    session.setAttribute("user", user);
	    model.addAttribute("username", username);

	    // Add a success message or redirect to the profile page
	    model.addAttribute("message", "Profile updated successfully.");
	    return "redirect:/profile";
	}


}
