package com.shtz.book_point.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shtz.book_point.entity.CartItem;
import com.shtz.book_point.entity.Order;
import com.shtz.book_point.entity.User;
import com.shtz.book_point.service.CartService;
import com.shtz.book_point.service.OrderService;

import jakarta.servlet.http.HttpSession;


@Controller
public class OrderController {
	private final OrderService orderService;
	private final CartService cartService;

    @Autowired
    public OrderController(OrderService orderService, CartService cartService) {
        this.orderService = orderService;
        this.cartService = cartService;
    }

    @GetMapping("/orderConfirm")
    public String showOrderConfirmation(HttpSession session, Model model) {
        // Retrieve user from session
        User user = (User) session.getAttribute("user");
        if (user == null) {
            throw new IllegalStateException("User is not logged in.");
        }

        // Retrieve cart from session
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            cart = Collections.emptyList(); // Ensure the cart is never null
        }

        // Calculate total price (handle empty cart case)
        int totalCartPrice = cart.isEmpty() ? 0 : cartService.calculateTotalPrice(session);

        // Add attributes to model
        model.addAttribute("user", user);
        model.addAttribute("cart", cart);
        model.addAttribute("totalCartPrice", totalCartPrice);

        return "order-confirmation"; // Thymeleaf template
    }


    @PostMapping("/orderPlace")
    public String placeOrder(RedirectAttributes redirectAttributes) {
        try {
            Order order = orderService.placeOrder();
            redirectAttributes.addFlashAttribute("success", "Order placed successfully!");
            return "redirect:/dashboard"; // Redirect directly to the dashboard
        } catch (IllegalStateException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
            return "redirect:/cart";
        }
    }

    @GetMapping("/orders")
    public String getOrders(HttpSession session, Model model) {
        // Retrieve user from session
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login"; // Redirect if not logged in
        }

        // Fetch orders for the logged-in user
        List<Order> orders = orderService.getOrdersByUserId(user.getId());

        // Add orders to model
        model.addAttribute("orders", orders);
        model.addAttribute("username", user.getUsername());

        return "orders"; // Render orders.html
    }
    

}
