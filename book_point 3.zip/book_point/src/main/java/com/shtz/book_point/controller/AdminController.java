package com.shtz.book_point.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.shtz.book_point.entity.Order;
import com.shtz.book_point.entity.User;
import com.shtz.book_point.service.AdminService;
import com.shtz.book_point.service.OrderService;
import com.shtz.book_point.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired
    private AdminService adminService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
    private UserService userService;

    @GetMapping("/login")
    public String showLoginPage() {
        return "admin_login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, HttpSession session, Model model) {
        if (adminService.authenticate(username, password)) {
            session.setAttribute("admin", username);
            return "redirect:/admin/dashboard";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "admin_login";
        }
    }

    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session) {
        if (session.getAttribute("admin") == null) {
            return "redirect:/admin/login";
        }
        return "admin_dashboard";
    }
    
    // Display all users
    @GetMapping("/viewUsers")
    public String viewUsers(Model model) {
        List<User> users = userService.getAllUsers();
        model.addAttribute("users", users);
        return "viewUsers";  // Refers to viewUsers.html
    }
    
    @GetMapping("/viewOrders")
    public String viewOrders(@RequestParam(value = "date", required = false) String date, Model model, HttpSession session) {
        if (session.getAttribute("admin") == null) {
            return "redirect:/admin/login"; // Ensure only logged-in admins can access
        }

        List<Order> orders;
        if (date == null || date.isEmpty()) {
            // Show all orders if no date is selected
            orders = orderService.getAllOrders(); 
        } else {
            // Filter orders by the selected date
            orders = orderService.getOrdersByDate(date);
        }

        model.addAttribute("orders", orders);
        model.addAttribute("selectedDate", date); // Add the selected date to the model
        return "viewOrders"; // Ensure this matches the actual HTML file name
    }
    
    @GetMapping("/viewOrder/{id}")
    public String viewOrder(@PathVariable Long id, Model model) {
        Order order = orderService.getOrderById(id);
        User user = userService.getUserById(order.getUserId());

        model.addAttribute("order", order);
        model.addAttribute("user", user);

        return "orderDetails"; // Refers to orderDetails.html
    }

    @PostMapping("/confirmOrder")
    public String confirmOrder(@RequestParam Long orderId) {
        orderService.updateOrderStatus(orderId, "confirmed");
        return "redirect:/admin/viewOrders";
    }

    @PostMapping("/rejectOrder")
    public String rejectOrder(@RequestParam Long orderId) {
        orderService.updateOrderStatus(orderId, "rejected");
        return "redirect:/admin/viewOrders";
    }

    @PostMapping("/completeOrder")
    public String completeOrder(@RequestParam Long orderId) {
        orderService.updateOrderStatus(orderId, "completed");
        return "redirect:/admin/viewOrders";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/admin/login";
    }

}
