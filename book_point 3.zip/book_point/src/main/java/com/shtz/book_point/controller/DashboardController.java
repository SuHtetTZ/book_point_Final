package com.shtz.book_point.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.shtz.book_point.entity.Book;
import com.shtz.book_point.service.BookService;

import jakarta.servlet.http.HttpSession;

@Controller
public class DashboardController {
	@Autowired
    private BookService bookService;

    // Display all books on the dashboard
    @GetMapping("/dashboard")
    public String showDashboard(HttpSession session, Model model) {
        // Get the username from session
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login"; // Redirect if not logged in
        }
        
        List<Book> books = bookService.getBooks();
        model.addAttribute("books", books);
        model.addAttribute("username", username);
        
        return "dashboard"; // Returns dashboard.html which lists all books
    }

    // View details for a selected book with recommendations
    @GetMapping("/viewbook/{id}")
    public String viewBookDetail(@PathVariable int id, HttpSession session, Model model) {
        // Get the username from session
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login"; // Redirect if not logged in
        }
        
        // Retrieve all books from the service
        List<Book> books = bookService.getBooks();
        Book selectedBook = null;
        for (Book book : books) {
            if (book.getId() == id) {
                selectedBook = book;
                break;
            }
        }
        
        // If the book is not found, redirect back to the dashboard
        if (selectedBook == null) {
            return "redirect:/dashboard";
        }
        
        model.addAttribute("book", selectedBook);
        model.addAttribute("username", username);
        
        // Retrieve recommended books based on the selected book
        /*List<Book> recommendedBooks = bookService.getRecommendedBooks(selectedBook);
        model.addAttribute("recommendedBooks", recommendedBooks);*/
        
        // Retrieve recommended books with similarity values
        List<Map.Entry<Book, Double>> recommendedBooks = bookService.getTopSimilarBooks(selectedBook, books);

        // Add the recommended books (with similarity scores) to the model
        model.addAttribute("recommendedBooks", recommendedBooks);
        
        return "viewbook"; // Returns viewbook.html which displays book details and recommendations
    }
    
    // the searched results display
    @GetMapping("/searchBook")
    public String searchBooks(@RequestParam("query") String query, HttpSession session, Model model) {
    	// Get the username from session
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login"; // Redirect if not logged in
        }
    	
        List<Book> books = bookService.searchBooksByTitle(query);
        model.addAttribute("username", username);
        model.addAttribute("books", books);
        model.addAttribute("query", query);
        return "search_results"; // Refers to the Thymeleaf template (search_results.html)
    }

    // search by genre page
    @GetMapping("/genre")
    public String showGenrePage(HttpSession session, Model model) {
        // Get the username from session
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login"; // Redirect if not logged in
        }
        model.addAttribute("username", username);
        
        return "genre"; // Returns dashboard.html which lists all books
    }
    
    @GetMapping("/searchByGenre")
    public String searchByGenre(@RequestParam String genre, HttpSession session, Model model) {
    	// Get the username from session
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login"; // Redirect if not logged in
        }
    	
    	// Call the service method to get the books by genre
        List<Book> books = bookService.searchBooksByGenre(genre);

        // Add the result to the model to be displayed
        model.addAttribute("books", books);
        model.addAttribute("username", username);
        model.addAttribute("genreValue", genre);
        return "genre"; // Name of the Thymeleaf template
    }
    
}
