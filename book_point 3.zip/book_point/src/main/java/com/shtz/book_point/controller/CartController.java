package com.shtz.book_point.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shtz.book_point.entity.Book;
import com.shtz.book_point.entity.CartItem;
import com.shtz.book_point.service.BookService;
import com.shtz.book_point.service.CartService;

import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
public class CartController {
	private final CartService cartService;
    private final BookService bookService;
    
    @PostMapping("/cartAdd")
    public String addToCart(@RequestParam int bookId, @RequestParam int quantity, HttpSession session, RedirectAttributes redirectAttributes) {
        Book book = bookService.findById(bookId);
        if (book != null) {
            cartService.addToCart(session, book, quantity);
            redirectAttributes.addFlashAttribute("message", "Item added to cart!"); // Flash message
        } else {
            redirectAttributes.addFlashAttribute("message", "Book not found.");
        }
        return "redirect:/viewbook/" + bookId; // Redirect to the book page
    }
    @GetMapping("/cart")
    public String viewCart(HttpSession session, Model model) {
        String username = (String) session.getAttribute("username");
        if (username == null) {
            return "redirect:/login";
        }

        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        int totalCartPrice = cartService.calculateTotalPrice(session); // Get total price

        model.addAttribute("username", username);
        model.addAttribute("cart", cart);
        model.addAttribute("totalCartPrice", totalCartPrice); // Pass total price to HTML
        return "cart";
    }

    @PostMapping("/cartRemove")
    public String removeFromCart(@RequestParam int bookId, HttpSession session, RedirectAttributes redirectAttributes) {
        cartService.removeFromCart(session, bookId);
        redirectAttributes.addFlashAttribute("message", "Item removed from cart!");
        return "redirect:/cart";
    }
    
    @PostMapping("/cartClear")
    public String clearCart(HttpSession session) {
        cartService.clearCart(session);
        return "redirect:/cart";
    }


}
