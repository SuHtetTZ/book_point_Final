package com.shtz.book_point.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.shtz.book_point.entity.Admin;

@Repository
public interface AdminRepository extends JpaRepository<Admin, Long>{
	// Query method to find an admin by username
    Admin findByUsername(String username);

}
