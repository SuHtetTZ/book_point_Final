package com.shtz.book_point.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shtz.book_point.entity.Admin;
import com.shtz.book_point.repo.AdminRepository;

@Service
public class AdminService {
	@Autowired
    private AdminRepository adminRepository;

	// Authenticate admin based on username and password
    public boolean authenticate(String username, String password) {
        // Find the admin by username
        Admin admin = adminRepository.findByUsername(username);
        
        if (admin != null && admin.getPassword().equals(password)) {
            // Username and password match
            return true;
        }
        // Invalid credentials
        return false;
    }

}
