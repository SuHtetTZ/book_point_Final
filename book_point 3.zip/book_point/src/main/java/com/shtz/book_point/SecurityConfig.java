package com.shtz.book_point;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
	
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/", 
                		"/login", 
                		"/register", 
                		"/profile", "/editProfile", "/updateProfile",
                		"/dashboard", 
                		"/logout", 
                		"/viewbook/*",
                		"/searchBook",
                		"/genre", "/searchByGenre",
                		"/cart", "/cartAdd", "/cartRemove", "/cartClear",
                		"/orderConfirm", "/orderPlace", "/orders",
                		"/admin", "/admin/login", "/admin/dashboard", "/admin/logout",
                		"/admin/**", "/admin//deleteUser/*",
                		"/css/**",
                		"/fonts/**",
                		"/logo/**").permitAll() // Allow public access
                .anyRequest().authenticated()
            )
            .csrf(csrf -> csrf.disable())
            .formLogin().disable();

        return http.build();
    }
	
	@Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
