package com.shtz.book_point.service;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.jfasttext.JFastText;
import com.shtz.book_point.entity.Book;
import com.shtz.book_point.repo.BookRepository;

import jakarta.annotation.PostConstruct;

@Service
public class BookService {
	
	@Autowired
    private BookRepository bookRepository;

    private List<Book> books = new ArrayList<>();
    private JFastText fastTextModel;

    @PostConstruct
    public void init() {
        loadBooks();
        loadFastTextModel();
    }

    private void loadFastTextModel() {
        fastTextModel = new JFastText();
        fastTextModel.loadModel(getClass().getClassLoader().getResource("cc.en.300.bin").getPath());
    }
    
    // search function
    public List<Book> searchBooksByTitle(String title) {
        return bookRepository.findByTitleIgnoreCaseContaining(title);
    }
    
    // search by genre
    public List<Book> searchBooksByGenre(String genre) {
        // Normalize the genre to lowercase and search for matching books
        String searchGenre = genre.toLowerCase(); // Make it case-insensitive

        // Search for books that contain the selected genre in the genre column
        return bookRepository.findByGenreContainingIgnoreCase(searchGenre);
    }

    // Load books from MySQL
    public Book findById(int id) {
        Optional<Book> book = bookRepository.findById(id);
        return book.orElse(null); // Return book or null if not found
    }
    
    public void loadBooks() {
        books = bookRepository.findAll();
    }

    // Return all books
    public List<Book> getBooks() {
        return books;
    }

    // Recommendation algorithm: Return top 10 recommended books for a given book
    /*public List<Book> getRecommendedBooks(Book targetBook) {
        if (books == null || books.isEmpty()) {
            return Collections.emptyList();
        }

        return books.stream()
                .filter(b -> b.getId() != targetBook.getId())
                .map(b -> new AbstractMap.SimpleEntry<Book, Double>(b, computeFinalSimilarity(targetBook, b)))
                .sorted(Comparator.comparingDouble((Map.Entry<Book, Double> entry) -> entry.getValue()).reversed())
                .limit(10)
                .map(AbstractMap.SimpleEntry::getKey)
                .collect(Collectors.toList());

    }*/
    public List<Map.Entry<Book, Double>> getTopSimilarBooks(Book targetBook, List<Book> books) {
        return books.stream()
            .filter(b -> b.getId() != targetBook.getId()) // Exclude the targetBook itself
            .map(b -> new AbstractMap.SimpleEntry<>(b, Math.round(computeFinalSimilarity(targetBook, b) * 100.0) / 100.0)) // Round to 2 decimal places
            .sorted(Comparator.comparingDouble(Map.Entry<Book, Double>::getValue).reversed()) // Sort by similarity score
            .limit(10) // Limit to top 10 similar books
            .collect(Collectors.toList()); // Collect the result into a list of Map.Entry<Book, Double>
    }




    // Combine similarity metrics for a final score
    private double computeFinalSimilarity(Book book1, Book book2) {
        double genreSim = jaccardSimilarity(book1.getGenre(), book2.getGenre());
        double tagSim = cosineSimilarity(book1.getTags(), book2.getTags());
        double authorSim = jaccardSimilarity(book1.getAuthor(), book2.getAuthor());

        return (3 * genreSim) + (1 * tagSim) + (2 * authorSim);
    }

    // Jaccard similarity
    private double jaccardSimilarity(String str1, String str2) {
        Set<String> set1 = new HashSet<>(Arrays.asList(str1.toLowerCase().split("\\s+")));
        Set<String> set2 = new HashSet<>(Arrays.asList(str2.toLowerCase().split("\\s+")));

        Set<String> intersection = new HashSet<>(set1);
        intersection.retainAll(set2);

        Set<String> union = new HashSet<>(set1);
        union.addAll(set2);

        return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
    }

    // Cosine similarity using FastText embeddings
    private double cosineSimilarity(String str1, String str2) {
        if (str1.isEmpty() || str2.isEmpty()) return 0.0;

        String[] tags1 = str1.toLowerCase().split("\\s+");
        String[] tags2 = str2.toLowerCase().split("\\s+");

        float[] embedding1 = computeAverageEmbedding(tags1);
        float[] embedding2 = computeAverageEmbedding(tags2);

        return computeCosineSimilarity(embedding1, embedding2);
    }

    // Compute average FastText embedding for a set of tags
    private float[] computeAverageEmbedding(String[] tags) {
        float[] sumEmbedding = new float[300]; // Assuming 300-dimensional FastText vectors
        int count = 0;

        for (String tag : tags) {
            List<Float> embeddingList = fastTextModel.getVector(tag.trim());

            if (embeddingList != null && !embeddingList.isEmpty()) {
                float[] embedding = new float[embeddingList.size()];
                for (int i = 0; i < embeddingList.size(); i++) {
                    embedding[i] = embeddingList.get(i);
                }

                for (int i = 0; i < embedding.length; i++) {
                    sumEmbedding[i] += embedding[i];
                }
                count++;
            }
        }

        if (count == 0) return new float[300];

        for (int i = 0; i < sumEmbedding.length; i++) {
            sumEmbedding[i] /= count;
        }

        return sumEmbedding;
    }

    // Compute cosine similarity between two embedding vectors
    private double computeCosineSimilarity(float[] embedding1, float[] embedding2) {
        if (embedding1 == null || embedding2 == null) return 0.0;

        double dotProduct = 0.0;
        double norm1 = 0.0;
        double norm2 = 0.0;

        for (int i = 0; i < embedding1.length; i++) {
            dotProduct += embedding1[i] * embedding2[i];
            norm1 += Math.pow(embedding1[i], 2);
            norm2 += Math.pow(embedding2[i], 2);
        }

        return dotProduct / (Math.sqrt(norm1) * Math.sqrt(norm2));
    }

	public Book getBookById(int id) {
		Optional<Book> book = bookRepository.findById(id);
        return book.orElse(null);
	}
}
