package com.shtz.book_point.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class CartItem {
	private Book book;
	private int quantity;
	
	// New method to calculate total price
    public int getTotalPrice() {
        return (int) (book.getPrice() * quantity);
    }

}
