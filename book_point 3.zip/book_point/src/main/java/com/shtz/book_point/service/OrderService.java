package com.shtz.book_point.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shtz.book_point.entity.Order;
import com.shtz.book_point.repo.OrderItemRepository;
import com.shtz.book_point.repo.OrderRepository;
import com.shtz.book_point.entity.User;
import com.shtz.book_point.entity.CartItem;
import com.shtz.book_point.entity.OrderItem;

import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;

@Service
public class OrderService {
	private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final HttpSession session; // Inject HttpSession to access user & cart

    @Autowired
    public OrderService(OrderRepository orderRepository, OrderItemRepository orderItemRepository, HttpSession session) {
        this.orderRepository = orderRepository;
        this.orderItemRepository = orderItemRepository;
        this.session = session;
    }
    
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
    
    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }
    
    public Order getOrderById(Long id) {
        return orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
    }

    public void updateOrderStatus(Long orderId, String status) {
        Order order = getOrderById(orderId);
        order.setStatus(status);
        orderRepository.save(order);
    }

    @Transactional
    public Order placeOrder() {
        // Retrieve user from session
        User user = (User) session.getAttribute("user");
        if (user == null) {
            throw new IllegalStateException("User is not logged in.");
        }

        // Retrieve cart from session
        List<CartItem> cart = getCart(session);
        if (cart.isEmpty()) {
            throw new IllegalStateException("Cart is empty.");
        }

        // Create new order
        Order order = new Order();
        order.setUserId(user.getId());
        order.setOrderDate(LocalDateTime.now());
        order.setTotalAmount(cart.stream().mapToInt(CartItem::getTotalPrice).sum());
        order.setStatus("pending"); // Ensure default status

        // Save order first (to generate order ID)
        order = orderRepository.save(order);

        // Create order items
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem item : cart) {
            OrderItem orderItem = new OrderItem();
            orderItem.setOrder(order);
            orderItem.setBook(item.getBook());
            orderItem.setQuantity(item.getQuantity());
            orderItem.setPrice(item.getBook().getPrice());
            orderItem.setTotalPrice(item.getTotalPrice());
            orderItems.add(orderItem);
        }

        // Save all order items
        orderItemRepository.saveAll(orderItems);

        // Clear session cart after order is placed
        session.removeAttribute("cart");

        return order;
    }
    
    //  Fix: Add getCart() method
    private List<CartItem> getCart(HttpSession session) {
        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
        return (cart != null) ? cart : new ArrayList<>();
    }

    public List<Order> getOrdersByDate(String date) {
        LocalDate selectedDate = LocalDate.parse(date); // Parse the selected date

        // Filter orders based on the date part of the LocalDateTime
        return orderRepository.findOrdersByDate(selectedDate.atStartOfDay(), selectedDate.plusDays(1).atStartOfDay());
    }

}
