package com.shtz.book_point.entity;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class User implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-generate the ID
    private Long id;  // Primary key for User entity

	@Column(unique = true)
	@NotEmpty(message = "Username is required")
    private String username;

	@Column(unique = true, nullable = false)
    @Email(message = "Email should be valid")
    @NotEmpty(message = "Email is required")
    private String email;
    
    @Column(unique = true)
	@NotEmpty(message = "Phone number is required")
    private String phone;
    
    @Column(nullable = false)
	@NotEmpty(message = "Address is required")
    private String address;

    @Column(nullable = false)
    private String password;
    
}
