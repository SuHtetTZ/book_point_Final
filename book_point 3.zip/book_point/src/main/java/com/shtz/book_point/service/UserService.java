package com.shtz.book_point.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shtz.book_point.entity.User;
import com.shtz.book_point.repo.UserRepository;

@Service
public class UserService {
    
	@Autowired
    private UserRepository userRepository;

    // Register user
    public User registerUser(User user) {
    	// Check if username, email, or phone is already taken
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username is already taken.");
        }
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email is already in use.");
        }
        if (userRepository.findByPhone(user.getPhone()).isPresent()) {
            throw new IllegalArgumentException("Phone number is already in use.");
        }
        if (user.getAddress() == null || user.getAddress().isEmpty()) {
            throw new IllegalArgumentException("Address is required.");
        }
        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            throw new IllegalArgumentException("Password is required.");
        }
    	
        // Save user (with auto-generated id)
        return userRepository.save(user);
    }

    
 // Login user
    public User loginUser(String email, String password) {
        Optional<User> userOptional = userRepository.findByEmail(email);

        if (userOptional.isEmpty()) {
            throw new IllegalArgumentException("No account found with this email.");
        }

        User user = userOptional.get();
        if (!user.getPassword().equals(password)) {
            throw new IllegalArgumentException("Incorrect password. Please try again.");
        }
        return user; // Valid login
    }
    
    // for admin controller usage
    public User getUserById(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
    }

	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	public void updateUserProfile(User user) {
		userRepository.save(user);	
	}

}
