package com.shtz.book_point;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookPointApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookPointApplication.class, args);
	}

}
